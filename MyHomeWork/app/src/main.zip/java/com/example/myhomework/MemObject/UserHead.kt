package com.example.myhomework.MemObject

import android.net.Uri

class UserHead(
    val userHeadUri:Int,
    val id:String,
    val historyMsg:String,
    val msgNum:Int) {

}