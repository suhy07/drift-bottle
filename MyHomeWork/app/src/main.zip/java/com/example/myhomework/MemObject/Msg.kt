package com.example.myhomework.MemObject

class Msg(val content:String,val type:Int){
    //定义静态成员
    companion object{
        const val RIGHT = 0
        const val LEFT = 1
    }
};